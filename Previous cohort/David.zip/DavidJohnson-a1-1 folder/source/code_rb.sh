#!/bin/bash

code controller.rb
code functions.rb
code classes.rb
code crawlerman.rb


