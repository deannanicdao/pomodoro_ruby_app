#!/bin/bash

bundle install

ruby controller.rb